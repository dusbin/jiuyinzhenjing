#pragma once
extern int passive_server(int port,int queue);
